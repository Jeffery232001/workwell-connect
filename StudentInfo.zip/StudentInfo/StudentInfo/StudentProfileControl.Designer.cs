﻿namespace StudentInfo
{
    partial class StudentProfileControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentProfileControl));
            this.Delete = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Update = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Add = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Hostel = new System.Windows.Forms.ComboBox();
            this.Course = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Index = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Refno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Age = new System.Windows.Forms.TextBox();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Surname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Stname = new System.Windows.Forms.TextBox();
            this.ProfileDataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProfileDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Delete
            // 
            this.Delete.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Delete.BorderRadius = 0;
            this.Delete.ButtonText = "DELETE";
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.DisabledColor = System.Drawing.Color.Gray;
            this.Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.Iconcolor = System.Drawing.Color.Transparent;
            this.Delete.Iconimage = ((System.Drawing.Image)(resources.GetObject("Delete.Iconimage")));
            this.Delete.Iconimage_right = null;
            this.Delete.Iconimage_right_Selected = null;
            this.Delete.Iconimage_Selected = null;
            this.Delete.IconMarginLeft = 0;
            this.Delete.IconMarginRight = 0;
            this.Delete.IconRightVisible = true;
            this.Delete.IconRightZoom = 0D;
            this.Delete.IconVisible = true;
            this.Delete.IconZoom = 90D;
            this.Delete.IsTab = false;
            this.Delete.Location = new System.Drawing.Point(161, 581);
            this.Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Delete.Name = "Delete";
            this.Delete.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Delete.OnHoverTextColor = System.Drawing.Color.White;
            this.Delete.selected = false;
            this.Delete.Size = new System.Drawing.Size(269, 64);
            this.Delete.TabIndex = 42;
            this.Delete.Text = "DELETE";
            this.Delete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Delete.Textcolor = System.Drawing.Color.White;
            this.Delete.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Update
            // 
            this.Update.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Update.BorderRadius = 0;
            this.Update.ButtonText = "UPDATE";
            this.Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Update.DisabledColor = System.Drawing.Color.Gray;
            this.Update.Iconcolor = System.Drawing.Color.Transparent;
            this.Update.Iconimage = ((System.Drawing.Image)(resources.GetObject("Update.Iconimage")));
            this.Update.Iconimage_right = null;
            this.Update.Iconimage_right_Selected = null;
            this.Update.Iconimage_Selected = null;
            this.Update.IconMarginLeft = 0;
            this.Update.IconMarginRight = 0;
            this.Update.IconRightVisible = true;
            this.Update.IconRightZoom = 0D;
            this.Update.IconVisible = true;
            this.Update.IconZoom = 90D;
            this.Update.IsTab = false;
            this.Update.Location = new System.Drawing.Point(279, 481);
            this.Update.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Update.Name = "Update";
            this.Update.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Update.OnHoverTextColor = System.Drawing.Color.White;
            this.Update.selected = false;
            this.Update.Size = new System.Drawing.Size(236, 80);
            this.Update.TabIndex = 41;
            this.Update.Text = "UPDATE";
            this.Update.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Update.Textcolor = System.Drawing.Color.White;
            this.Update.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // Add
            // 
            this.Add.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Add.BorderRadius = 0;
            this.Add.ButtonText = "ADD";
            this.Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add.DisabledColor = System.Drawing.Color.Gray;
            this.Add.Iconcolor = System.Drawing.Color.Transparent;
            this.Add.Iconimage = ((System.Drawing.Image)(resources.GetObject("Add.Iconimage")));
            this.Add.Iconimage_right = null;
            this.Add.Iconimage_right_Selected = null;
            this.Add.Iconimage_Selected = null;
            this.Add.IconMarginLeft = 0;
            this.Add.IconMarginRight = 0;
            this.Add.IconRightVisible = true;
            this.Add.IconRightZoom = 0D;
            this.Add.IconVisible = true;
            this.Add.IconZoom = 90D;
            this.Add.IsTab = false;
            this.Add.Location = new System.Drawing.Point(6, 481);
            this.Add.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Add.Name = "Add";
            this.Add.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Add.OnHoverTextColor = System.Drawing.Color.White;
            this.Add.selected = false;
            this.Add.Size = new System.Drawing.Size(246, 80);
            this.Add.TabIndex = 40;
            this.Add.Text = "ADD";
            this.Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add.Textcolor = System.Drawing.Color.White;
            this.Add.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.ImageLocation = "center";
            this.pictureBox1.Location = new System.Drawing.Point(101, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 94);
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(217, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 37);
            this.label1.TabIndex = 46;
            this.label1.Text = "Student Profile";
            // 
            // Hostel
            // 
            this.Hostel.FormattingEnabled = true;
            this.Hostel.Items.AddRange(new object[] {
            "MMOH",
            "ZION HOSTEL",
            "ANGELA HOSTEL",
            "DANIEL QUAW HOSTEL"});
            this.Hostel.Location = new System.Drawing.Point(364, 380);
            this.Hostel.Name = "Hostel";
            this.Hostel.Size = new System.Drawing.Size(151, 24);
            this.Hostel.TabIndex = 55;
            // 
            // Course
            // 
            this.Course.FormattingEnabled = true;
            this.Course.Items.AddRange(new object[] {
            "COMPUTER SCIENCE AND ENGINEERING",
            "MECHANICAL ENGINEERING",
            "ELECTRICAL ENGINEERING",
            "GEOLOGICAL ENGINEERING"});
            this.Course.Location = new System.Drawing.Point(101, 383);
            this.Course.Name = "Course";
            this.Course.Size = new System.Drawing.Size(151, 24);
            this.Course.TabIndex = 54;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 383);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 21);
            this.label8.TabIndex = 53;
            this.label8.Text = "Course";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(263, 383);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 21);
            this.label7.TabIndex = 52;
            this.label7.Text = "Hostel";
            // 
            // Index
            // 
            this.Index.Location = new System.Drawing.Point(364, 309);
            this.Index.Multiline = true;
            this.Index.Name = "Index";
            this.Index.Size = new System.Drawing.Size(151, 34);
            this.Index.TabIndex = 51;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(264, 322);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 21);
            this.label6.TabIndex = 50;
            this.label6.Text = "Contact";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 322);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 21);
            this.label3.TabIndex = 49;
            this.label3.Text = "Ref No.";
            // 
            // Refno
            // 
            this.Refno.Location = new System.Drawing.Point(101, 309);
            this.Refno.Multiline = true;
            this.Refno.Name = "Refno";
            this.Refno.Size = new System.Drawing.Size(151, 34);
            this.Refno.TabIndex = 48;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 21);
            this.label2.TabIndex = 65;
            this.label2.Text = "Age";
            // 
            // Age
            // 
            this.Age.Location = new System.Drawing.Point(101, 233);
            this.Age.Multiline = true;
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(151, 34);
            this.Age.TabIndex = 64;
            // 
            // Gender
            // 
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "MALE",
            "FEMALE"});
            this.Gender.Location = new System.Drawing.Point(370, 233);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(151, 24);
            this.Gender.TabIndex = 67;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(270, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 21);
            this.label5.TabIndex = 66;
            this.label5.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(264, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 21);
            this.label4.TabIndex = 71;
            this.label4.Text = "Surname";
            // 
            // Surname
            // 
            this.Surname.Location = new System.Drawing.Point(364, 154);
            this.Surname.Multiline = true;
            this.Surname.Name = "Surname";
            this.Surname.Size = new System.Drawing.Size(151, 34);
            this.Surname.TabIndex = 69;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1, 167);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 21);
            this.label9.TabIndex = 73;
            this.label9.Text = "Name";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // Stname
            // 
            this.Stname.Location = new System.Drawing.Point(101, 154);
            this.Stname.Multiline = true;
            this.Stname.Name = "Stname";
            this.Stname.Size = new System.Drawing.Size(151, 34);
            this.Stname.TabIndex = 72;
            this.Stname.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ProfileDataGridView
            // 
            this.ProfileDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProfileDataGridView.Location = new System.Drawing.Point(527, 3);
            this.ProfileDataGridView.Name = "ProfileDataGridView";
            this.ProfileDataGridView.RowHeadersWidth = 51;
            this.ProfileDataGridView.RowTemplate.Height = 24;
            this.ProfileDataGridView.Size = new System.Drawing.Size(562, 696);
            this.ProfileDataGridView.TabIndex = 74;
            this.ProfileDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ProfileDataGridView_CellContentClick);
            // 
            // StudentProfileControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.Controls.Add(this.ProfileDataGridView);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Stname);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Surname);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Age);
            this.Controls.Add(this.Hostel);
            this.Controls.Add(this.Course);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Index);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Refno);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Add);
            this.Name = "StudentProfileControl";
            this.Size = new System.Drawing.Size(1110, 724);
            this.Load += new System.EventHandler(this.StudentProfileControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProfileDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuFlatButton Delete;
        private Bunifu.Framework.UI.BunifuFlatButton Update;
        private Bunifu.Framework.UI.BunifuFlatButton Add;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Hostel;
        private System.Windows.Forms.ComboBox Course;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Index;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Refno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Age;
        private System.Windows.Forms.ComboBox Gender;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Surname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Stname;
        private System.Windows.Forms.DataGridView ProfileDataGridView;
    }
}
