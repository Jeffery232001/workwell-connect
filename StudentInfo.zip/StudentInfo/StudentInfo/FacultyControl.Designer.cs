﻿namespace StudentInfo
{
    partial class FacultyControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FacultyControl));
            this.FacName = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Head = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Delete = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Update = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Add = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.FacultyDataGridView = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FacultyDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // FacName
            // 
            this.FacName.FormattingEnabled = true;
            this.FacName.Items.AddRange(new object[] {
            "FGES",
            "FIMS",
            "FMRT",
            "FOE"});
            this.FacName.Location = new System.Drawing.Point(195, 188);
            this.FacName.Name = "FacName";
            this.FacName.Size = new System.Drawing.Size(151, 24);
            this.FacName.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(59, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 21);
            this.label5.TabIndex = 41;
            this.label5.Text = "New courses";
            // 
            // Head
            // 
            this.Head.Location = new System.Drawing.Point(195, 273);
            this.Head.Multiline = true;
            this.Head.Name = "Head";
            this.Head.Size = new System.Drawing.Size(151, 41);
            this.Head.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(173, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(284, 37);
            this.label1.TabIndex = 36;
            this.label1.Text = "Data management";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(59, 293);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 21);
            this.label2.TabIndex = 43;
            this.label2.Text = "New Std";
            // 
            // Delete
            // 
            this.Delete.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Delete.BorderRadius = 0;
            this.Delete.ButtonText = "DELETE";
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.DisabledColor = System.Drawing.Color.Gray;
            this.Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.Iconcolor = System.Drawing.Color.Transparent;
            this.Delete.Iconimage = ((System.Drawing.Image)(resources.GetObject("Delete.Iconimage")));
            this.Delete.Iconimage_right = null;
            this.Delete.Iconimage_right_Selected = null;
            this.Delete.Iconimage_Selected = null;
            this.Delete.IconMarginLeft = 0;
            this.Delete.IconMarginRight = 0;
            this.Delete.IconRightVisible = true;
            this.Delete.IconRightZoom = 0D;
            this.Delete.IconVisible = true;
            this.Delete.IconZoom = 90D;
            this.Delete.IsTab = false;
            this.Delete.Location = new System.Drawing.Point(119, 554);
            this.Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Delete.Name = "Delete";
            this.Delete.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Delete.OnHoverTextColor = System.Drawing.Color.White;
            this.Delete.selected = false;
            this.Delete.Size = new System.Drawing.Size(246, 67);
            this.Delete.TabIndex = 46;
            this.Delete.Text = "DELETE";
            this.Delete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Delete.Textcolor = System.Drawing.Color.White;
            this.Delete.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // Update
            // 
            this.Update.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Update.BorderRadius = 0;
            this.Update.ButtonText = "UPDATE";
            this.Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Update.DisabledColor = System.Drawing.Color.Gray;
            this.Update.Iconcolor = System.Drawing.Color.Transparent;
            this.Update.Iconimage = ((System.Drawing.Image)(resources.GetObject("Update.Iconimage")));
            this.Update.Iconimage_right = null;
            this.Update.Iconimage_right_Selected = null;
            this.Update.Iconimage_Selected = null;
            this.Update.IconMarginLeft = 0;
            this.Update.IconMarginRight = 0;
            this.Update.IconRightVisible = true;
            this.Update.IconRightZoom = 0D;
            this.Update.IconVisible = true;
            this.Update.IconZoom = 90D;
            this.Update.IsTab = false;
            this.Update.Location = new System.Drawing.Point(253, 451);
            this.Update.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Update.Name = "Update";
            this.Update.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Update.OnHoverTextColor = System.Drawing.Color.White;
            this.Update.selected = false;
            this.Update.Size = new System.Drawing.Size(222, 80);
            this.Update.TabIndex = 45;
            this.Update.Text = "UPDATE";
            this.Update.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Update.Textcolor = System.Drawing.Color.White;
            this.Update.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // Add
            // 
            this.Add.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Add.BorderRadius = 0;
            this.Add.ButtonText = "ADD";
            this.Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add.DisabledColor = System.Drawing.Color.Gray;
            this.Add.Iconcolor = System.Drawing.Color.Transparent;
            this.Add.Iconimage = ((System.Drawing.Image)(resources.GetObject("Add.Iconimage")));
            this.Add.Iconimage_right = null;
            this.Add.Iconimage_right_Selected = null;
            this.Add.Iconimage_Selected = null;
            this.Add.IconMarginLeft = 0;
            this.Add.IconMarginRight = 0;
            this.Add.IconRightVisible = true;
            this.Add.IconRightZoom = 0D;
            this.Add.IconVisible = true;
            this.Add.IconZoom = 90D;
            this.Add.IsTab = false;
            this.Add.Location = new System.Drawing.Point(5, 451);
            this.Add.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Add.Name = "Add";
            this.Add.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Add.OnHoverTextColor = System.Drawing.Color.White;
            this.Add.selected = false;
            this.Add.Size = new System.Drawing.Size(211, 80);
            this.Add.TabIndex = 44;
            this.Add.Text = "ADD";
            this.Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add.Textcolor = System.Drawing.Color.White;
            this.Add.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.ImageLocation = "tile";
            this.pictureBox1.Location = new System.Drawing.Point(42, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 105);
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            // 
            // FacultyDataGridView
            // 
            this.FacultyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FacultyDataGridView.Location = new System.Drawing.Point(544, 0);
            this.FacultyDataGridView.Name = "FacultyDataGridView";
            this.FacultyDataGridView.RowHeadersWidth = 51;
            this.FacultyDataGridView.RowTemplate.Height = 24;
            this.FacultyDataGridView.Size = new System.Drawing.Size(562, 696);
            this.FacultyDataGridView.TabIndex = 48;
            this.FacultyDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FacultyDataGridView_CellContentClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 371);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 21);
            this.label3.TabIndex = 50;
            this.label3.Text = "Grades";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(195, 351);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(151, 41);
            this.textBox1.TabIndex = 49;
            // 
            // FacultyControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.FacultyDataGridView);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FacName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Head);
            this.Name = "FacultyControl";
            this.Size = new System.Drawing.Size(1106, 702);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FacultyDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox FacName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Head;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuFlatButton Delete;
        private Bunifu.Framework.UI.BunifuFlatButton Update;
        private Bunifu.Framework.UI.BunifuFlatButton Add;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView FacultyDataGridView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
    }
}
