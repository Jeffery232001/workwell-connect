﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentInfo
{
    public partial class FacultyControl : UserControl
    {

        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\hp pc\Documents\student.mdf"";Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            connect.Open();
            string Myquery = "select * from Faculty";
            SqlDataAdapter dataAdapter = new SqlDataAdapter(Myquery, connect);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            FacultyDataGridView.ReadOnly = true;
            FacultyDataGridView.DataSource = ds.Tables[0];
            connect.Close();
        }
        public FacultyControl()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FacultyDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FacName.Text = FacultyDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            Head.Text = FacultyDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            
        }
    }
}
