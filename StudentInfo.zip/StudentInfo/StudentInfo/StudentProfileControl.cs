﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace StudentInfo
{
    public partial class StudentProfileControl : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\hp pc\Documents\student.mdf"";Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            connect.Open();
            string Myquery = "select * from Profile";
            SqlDataAdapter dataAdapter = new SqlDataAdapter(Myquery, connect);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            ProfileDataGridView.ReadOnly = true;
            ProfileDataGridView.DataSource = ds.Tables[0];
            connect.Close();
        }



        
        public StudentProfileControl()
        {
            InitializeComponent();
        }

        private void StudentProfileControl_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (Stname.Text == "" || Surname.Text == "" || Age.Text == "" || Gender.SelectedItem == null || Refno.Text == "" || Index.Text == "" ||  Course.SelectedItem == null || Hostel.SelectedItem == null || Course.SelectedItem == null )
            {
                MessageBox.Show("Missing Data.Fill All the Information");
            }
            else
            {


                connect.Open();
                SqlCommand cmd = new SqlCommand("insert into SData values('" + Index.Text + "','" + Stname.Text + "','" + Surname.Text + "','" + Age.Text + "','" + Gender.SelectedItem.ToString() + "','" + Refno.Text + "','"  + Hostel.SelectedItem.ToString() + "','" + Course.SelectedItem.ToString() + "')", connect);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student Successfully Added");
                connect.Close();
                populate();
            }
        }

        private void ProfileDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Stname.Text = ProfileDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            Surname.Text = ProfileDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            Age.Text = ProfileDataGridView.SelectedRows[0].Cells[2].Value.ToString();
            Gender.Text = ProfileDataGridView.SelectedRows[0].Cells[3].Value.ToString();
            Refno.Text = ProfileDataGridView.SelectedRows[0].Cells[4].Value.ToString();
            Index.Text = ProfileDataGridView.SelectedRows[0].Cells[5].Value.ToString();
            Course.Text = ProfileDataGridView.SelectedRows[0].Cells[6].Value.ToString();
            Hostel.Text = ProfileDataGridView.SelectedRows[0].Cells[7].Value.ToString();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            connect.Open();
            String Myquery = "UPDATE Profile SET NAME = '" + Stname.Text + "', SURNAME = '" + Surname.Text + "', AGE = '" + Age.Text + "', Gender = '" + Gender.SelectedItem.ToString() + "',REFNO = '" + Refno.Text + "',INDEX = '" + Index.Text + "',COURSE = '" + Course.SelectedItem.ToString() + "',HOSTEL = '" + Hostel.SelectedItem.ToString() + "' WHERE REFNO = '" + Refno.Text + "';";


            SqlCommand cmd = new SqlCommand(Myquery, connect);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Student data Updated Successfully");
            connect.Close();
            populate();
        }

        private void Delete_Click(object sender, EventArgs e)
        {

            if (Stname.Text == "")
            {
                MessageBox.Show("Wrong Operation.Click on the medicine to be Deleted");
            }
            else
            {
                if (DialogResult.Yes == MessageBox.Show("Are you sure to delete row?", "Comfirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {
                    connect.Open();
                    string query = "DELETE FROM Profile WHERE NAME = '" + Stname.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, connect);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Record Deleted Successfully");
                    connect.Close();
                    populate();
                }
            }
        }
    }
}
