﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentInfo
{

    public partial class DepartmentControl : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\hp pc\Documents\student.mdf"";Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            connect.Open();
            string Myquery = "select * from Department";
            SqlDataAdapter dataAdapter = new SqlDataAdapter(Myquery, connect);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            DeptDataGridView.ReadOnly = true;
            DeptDataGridView.DataSource = ds.Tables[0];
            connect.Close();
        }
        public DepartmentControl()
        {
            InitializeComponent();
        }

        private void DeptDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Deptid.Text = DeptDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            Fac.Text = DeptDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            DeptName.Text = DeptDataGridView.SelectedRows[0].Cells[2].Value.ToString();

        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (Deptid.Text == "" || Fac.SelectedItem == null || DeptName.Text == "" )
            {
                MessageBox.Show("Missing Data.Fill All the Information");
            }
            else
            {

                connect.Open();
                SqlCommand cmd = new SqlCommand("insert into Department values('" + Deptid.Text + "','" + Fac.SelectedItem.ToString() + "','" + DeptName.Text + "')", connect);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Department Successfully Added");
                connect.Close();
                populate();
            }
        }

        private void Update_Click(object sender, EventArgs e)
        {
            connect.Open();
            String Myquery = "UPDATE Department SET DEPARTID = '" + Deptid.Text + "', FACULTY = '" + Fac.SelectedItem.ToString() + "',NAME ='" + DeptName.Text + "'  WHERE DEPARTID = '" + Deptid.Text + "';";


            SqlCommand cmd = new SqlCommand(Myquery, connect);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Department Updated Successfully");
            connect.Close();
            populate();

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (Deptid.Text == "")
            {
                MessageBox.Show("Wrong Operation.Click on the Department to be Deleted");
            }
            else
            {
                if (DialogResult.Yes == MessageBox.Show("Are you sure to delete row?", "Comfirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {
                    connect.Open();
                    string query = "insert into Department values('" + Deptid.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, connect);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Departmen Deleted Successfully");
                    connect.Close();
                    populate();

                }

            }

        }

        private void DepartmentControl_Load(object sender, EventArgs e)
        {

        }
    }
}
