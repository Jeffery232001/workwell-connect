﻿using System;
using System.Windows.Forms;

namespace StudentInfo
{
    public partial class Homepage : Form
    {
        public Homepage()
        {
            InitializeComponent();
        }

        private void Homepage_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 6;
            if (panel2.Width >= 525)
            {
                timer1.Stop();
                LoginPage method = new LoginPage();
                method.Show();
                this.Hide();
            }
        }
    }
}
