﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace StudentInfo
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            StudentProfileControl studentProfileControl = new StudentProfileControl();  
            addUserControl(studentProfileControl);
        }


        private void addUserControl(UserControl uc)
        {
            panelContainer.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
            panelContainer.Controls.Add(uc);
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            DashboardControl dc = new DashboardControl();
            addUserControl(dc);
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {

            GradeControl gc = new GradeControl();
            addUserControl(gc);
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {

            logoutControl lc = new logoutControl();
            addUserControl(lc);
        }
        private void  panelContainer_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton2_Click_1(object sender, EventArgs e)
        {
            GradeControl gc = new GradeControl();
            addUserControl(gc);
        }

        private void bunifuFlatButton3_Click_1(object sender, EventArgs e)
        {

            FacultyControl fc = new FacultyControl();
            addUserControl(fc);
        }

        private void bunifuFlatButton4_Click_1(object sender, EventArgs e)
        {

            DepartmentControl dc = new DepartmentControl();
            addUserControl(dc);

        }

        private void bunifuFlatButton6_Click_1(object sender, EventArgs e)
        {
            LoginPage login = new LoginPage();
            login.Show();
            this.Hide();
        }
    }
}
