﻿namespace StudentInfo
{
    partial class DepartmentControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DepartmentControl));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Delete = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Update = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Add = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Deptid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Fac = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.DeptName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DeptDataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeptDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.ImageLocation = "center";
            this.pictureBox1.Location = new System.Drawing.Point(51, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 96);
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(167, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 37);
            this.label1.TabIndex = 48;
            this.label1.Text = "COURSE";
            // 
            // Delete
            // 
            this.Delete.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Delete.BorderRadius = 0;
            this.Delete.ButtonText = "DELETE";
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.DisabledColor = System.Drawing.Color.Gray;
            this.Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.Iconcolor = System.Drawing.Color.Transparent;
            this.Delete.Iconimage = ((System.Drawing.Image)(resources.GetObject("Delete.Iconimage")));
            this.Delete.Iconimage_right = null;
            this.Delete.Iconimage_right_Selected = null;
            this.Delete.Iconimage_Selected = null;
            this.Delete.IconMarginLeft = 0;
            this.Delete.IconMarginRight = 0;
            this.Delete.IconRightVisible = true;
            this.Delete.IconRightZoom = 0D;
            this.Delete.IconVisible = true;
            this.Delete.IconZoom = 90D;
            this.Delete.IsTab = false;
            this.Delete.Location = new System.Drawing.Point(155, 575);
            this.Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Delete.Name = "Delete";
            this.Delete.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Delete.OnHoverTextColor = System.Drawing.Color.White;
            this.Delete.selected = false;
            this.Delete.Size = new System.Drawing.Size(269, 64);
            this.Delete.TabIndex = 45;
            this.Delete.Text = "DELETE";
            this.Delete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Delete.Textcolor = System.Drawing.Color.White;
            this.Delete.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Update
            // 
            this.Update.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Update.BorderRadius = 0;
            this.Update.ButtonText = "UPDATE";
            this.Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Update.DisabledColor = System.Drawing.Color.Gray;
            this.Update.Iconcolor = System.Drawing.Color.Transparent;
            this.Update.Iconimage = ((System.Drawing.Image)(resources.GetObject("Update.Iconimage")));
            this.Update.Iconimage_right = null;
            this.Update.Iconimage_right_Selected = null;
            this.Update.Iconimage_Selected = null;
            this.Update.IconMarginLeft = 0;
            this.Update.IconMarginRight = 0;
            this.Update.IconRightVisible = true;
            this.Update.IconRightZoom = 0D;
            this.Update.IconVisible = true;
            this.Update.IconZoom = 90D;
            this.Update.IsTab = false;
            this.Update.Location = new System.Drawing.Point(273, 475);
            this.Update.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Update.Name = "Update";
            this.Update.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Update.OnHoverTextColor = System.Drawing.Color.White;
            this.Update.selected = false;
            this.Update.Size = new System.Drawing.Size(236, 80);
            this.Update.TabIndex = 44;
            this.Update.Text = "UPDATE";
            this.Update.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Update.Textcolor = System.Drawing.Color.White;
            this.Update.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // Add
            // 
            this.Add.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Add.BorderRadius = 0;
            this.Add.ButtonText = "ADD";
            this.Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add.DisabledColor = System.Drawing.Color.Gray;
            this.Add.Iconcolor = System.Drawing.Color.Transparent;
            this.Add.Iconimage = ((System.Drawing.Image)(resources.GetObject("Add.Iconimage")));
            this.Add.Iconimage_right = null;
            this.Add.Iconimage_right_Selected = null;
            this.Add.Iconimage_Selected = null;
            this.Add.IconMarginLeft = 0;
            this.Add.IconMarginRight = 0;
            this.Add.IconRightVisible = true;
            this.Add.IconRightZoom = 0D;
            this.Add.IconVisible = true;
            this.Add.IconZoom = 90D;
            this.Add.IsTab = false;
            this.Add.Location = new System.Drawing.Point(0, 475);
            this.Add.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Add.Name = "Add";
            this.Add.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Add.OnHoverTextColor = System.Drawing.Color.White;
            this.Add.selected = false;
            this.Add.Size = new System.Drawing.Size(246, 80);
            this.Add.TabIndex = 43;
            this.Add.Text = "ADD";
            this.Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add.Textcolor = System.Drawing.Color.White;
            this.Add.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Deptid
            // 
            this.Deptid.Location = new System.Drawing.Point(212, 166);
            this.Deptid.Multiline = true;
            this.Deptid.Name = "Deptid";
            this.Deptid.Size = new System.Drawing.Size(151, 34);
            this.Deptid.TabIndex = 78;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(92, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 21);
            this.label4.TabIndex = 77;
            this.label4.Text = "Course Id";
            // 
            // Fac
            // 
            this.Fac.FormattingEnabled = true;
            this.Fac.Items.AddRange(new object[] {
            "Computer Science and Engineering",
            "Electrical Engineering",
            "Mechanical Engineering",
            "Geological Engineering",
            "Mathematics"});
            this.Fac.Location = new System.Drawing.Point(212, 249);
            this.Fac.Name = "Fac";
            this.Fac.Size = new System.Drawing.Size(151, 24);
            this.Fac.TabIndex = 75;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(69, 252);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 21);
            this.label5.TabIndex = 74;
            this.label5.Text = "Course Name";
            // 
            // DeptName
            // 
            this.DeptName.Location = new System.Drawing.Point(212, 322);
            this.DeptName.Multiline = true;
            this.DeptName.Name = "DeptName";
            this.DeptName.Size = new System.Drawing.Size(151, 34);
            this.DeptName.TabIndex = 73;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 335);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 21);
            this.label2.TabIndex = 79;
            this.label2.Text = "Instructor Name";
            // 
            // DeptDataGridView
            // 
            this.DeptDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DeptDataGridView.Location = new System.Drawing.Point(546, 3);
            this.DeptDataGridView.Name = "DeptDataGridView";
            this.DeptDataGridView.RowHeadersWidth = 51;
            this.DeptDataGridView.RowTemplate.Height = 24;
            this.DeptDataGridView.Size = new System.Drawing.Size(562, 696);
            this.DeptDataGridView.TabIndex = 80;
            this.DeptDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DeptDataGridView_CellContentClick);
            // 
            // DepartmentControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.Controls.Add(this.DeptDataGridView);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Deptid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Fac);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.DeptName);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.label1);
            this.Name = "DepartmentControl";
            this.Size = new System.Drawing.Size(1124, 718);
            this.Load += new System.EventHandler(this.DepartmentControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeptDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuFlatButton Delete;
        private Bunifu.Framework.UI.BunifuFlatButton Update;
        private Bunifu.Framework.UI.BunifuFlatButton Add;
        private System.Windows.Forms.TextBox Deptid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox Fac;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox DeptName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView DeptDataGridView;
    }
}
