﻿namespace StudentInfo
{
    partial class GradeControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GradeControl));
            this.Delete = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Update = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Add = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label2 = new System.Windows.Forms.Label();
            this.Year2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Year1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Year3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Year4 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.StdName = new System.Windows.Forms.TextBox();
            this.GradeDataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GradeDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Delete
            // 
            this.Delete.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Delete.BorderRadius = 0;
            this.Delete.ButtonText = "DELETE";
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.DisabledColor = System.Drawing.Color.Gray;
            this.Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.Iconcolor = System.Drawing.Color.Transparent;
            this.Delete.Iconimage = ((System.Drawing.Image)(resources.GetObject("Delete.Iconimage")));
            this.Delete.Iconimage_right = null;
            this.Delete.Iconimage_right_Selected = null;
            this.Delete.Iconimage_Selected = null;
            this.Delete.IconMarginLeft = 0;
            this.Delete.IconMarginRight = 0;
            this.Delete.IconRightVisible = true;
            this.Delete.IconRightZoom = 0D;
            this.Delete.IconVisible = true;
            this.Delete.IconZoom = 90D;
            this.Delete.IsTab = false;
            this.Delete.Location = new System.Drawing.Point(172, 600);
            this.Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Delete.Name = "Delete";
            this.Delete.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Delete.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Delete.OnHoverTextColor = System.Drawing.Color.White;
            this.Delete.selected = false;
            this.Delete.Size = new System.Drawing.Size(269, 64);
            this.Delete.TabIndex = 23;
            this.Delete.Text = "DELETE";
            this.Delete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Delete.Textcolor = System.Drawing.Color.White;
            this.Delete.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Update
            // 
            this.Update.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Update.BorderRadius = 0;
            this.Update.ButtonText = "UPDATE";
            this.Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Update.DisabledColor = System.Drawing.Color.Gray;
            this.Update.Iconcolor = System.Drawing.Color.Transparent;
            this.Update.Iconimage = ((System.Drawing.Image)(resources.GetObject("Update.Iconimage")));
            this.Update.Iconimage_right = null;
            this.Update.Iconimage_right_Selected = null;
            this.Update.Iconimage_Selected = null;
            this.Update.IconMarginLeft = 0;
            this.Update.IconMarginRight = 0;
            this.Update.IconRightVisible = true;
            this.Update.IconRightZoom = 0D;
            this.Update.IconVisible = true;
            this.Update.IconZoom = 90D;
            this.Update.IsTab = false;
            this.Update.Location = new System.Drawing.Point(281, 500);
            this.Update.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Update.Name = "Update";
            this.Update.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Update.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Update.OnHoverTextColor = System.Drawing.Color.White;
            this.Update.selected = false;
            this.Update.Size = new System.Drawing.Size(236, 80);
            this.Update.TabIndex = 22;
            this.Update.Text = "UPDATE";
            this.Update.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Update.Textcolor = System.Drawing.Color.White;
            this.Update.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // Add
            // 
            this.Add.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Add.BorderRadius = 0;
            this.Add.ButtonText = "ADD";
            this.Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add.DisabledColor = System.Drawing.Color.Gray;
            this.Add.Iconcolor = System.Drawing.Color.Transparent;
            this.Add.Iconimage = ((System.Drawing.Image)(resources.GetObject("Add.Iconimage")));
            this.Add.Iconimage_right = null;
            this.Add.Iconimage_right_Selected = null;
            this.Add.Iconimage_Selected = null;
            this.Add.IconMarginLeft = 0;
            this.Add.IconMarginRight = 0;
            this.Add.IconRightVisible = true;
            this.Add.IconRightZoom = 0D;
            this.Add.IconVisible = true;
            this.Add.IconZoom = 90D;
            this.Add.IsTab = false;
            this.Add.Location = new System.Drawing.Point(17, 500);
            this.Add.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Add.Name = "Add";
            this.Add.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Add.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Add.OnHoverTextColor = System.Drawing.Color.White;
            this.Add.selected = false;
            this.Add.Size = new System.Drawing.Size(246, 80);
            this.Add.TabIndex = 21;
            this.Add.Text = "ADD";
            this.Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add.Textcolor = System.Drawing.Color.White;
            this.Add.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 283);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 21);
            this.label2.TabIndex = 32;
            this.label2.Text = "Course";
            // 
            // Year2
            // 
            this.Year2.Location = new System.Drawing.Point(136, 270);
            this.Year2.Multiline = true;
            this.Year2.Name = "Year2";
            this.Year2.Size = new System.Drawing.Size(151, 34);
            this.Year2.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 21);
            this.label1.TabIndex = 35;
            this.label1.Text = "Grade Value";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Year1
            // 
            this.Year1.Location = new System.Drawing.Point(136, 211);
            this.Year1.Multiline = true;
            this.Year1.Name = "Year1";
            this.Year1.Size = new System.Drawing.Size(151, 34);
            this.Year1.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 346);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 21);
            this.label3.TabIndex = 37;
            this.label3.Text = "Date";
            // 
            // Year3
            // 
            this.Year3.Location = new System.Drawing.Point(136, 333);
            this.Year3.Multiline = true;
            this.Year3.Name = "Year3";
            this.Year3.Size = new System.Drawing.Size(151, 34);
            this.Year3.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 401);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 21);
            this.label4.TabIndex = 39;
            this.label4.Text = "CourseID";
            // 
            // Year4
            // 
            this.Year4.Location = new System.Drawing.Point(136, 388);
            this.Year4.Multiline = true;
            this.Year4.Name = "Year4";
            this.Year4.Size = new System.Drawing.Size(151, 34);
            this.Year4.TabIndex = 38;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(13, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 94);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Elephant", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(129, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 37);
            this.label5.TabIndex = 40;
            this.label5.Text = "Grades";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Fax", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 21);
            this.label6.TabIndex = 43;
            this.label6.Text = "Name";
            // 
            // StdName
            // 
            this.StdName.Location = new System.Drawing.Point(136, 159);
            this.StdName.Multiline = true;
            this.StdName.Name = "StdName";
            this.StdName.Size = new System.Drawing.Size(151, 34);
            this.StdName.TabIndex = 42;
            // 
            // GradeDataGridView
            // 
            this.GradeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GradeDataGridView.Location = new System.Drawing.Point(548, 3);
            this.GradeDataGridView.Name = "GradeDataGridView";
            this.GradeDataGridView.RowHeadersWidth = 51;
            this.GradeDataGridView.RowTemplate.Height = 24;
            this.GradeDataGridView.Size = new System.Drawing.Size(562, 696);
            this.GradeDataGridView.TabIndex = 44;
            this.GradeDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GradeDataGridView_CellContentClick);
            // 
            // GradeControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.Controls.Add(this.GradeDataGridView);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.StdName);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Year4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Year3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Year1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Year2);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Add);
            this.Name = "GradeControl";
            this.Size = new System.Drawing.Size(1113, 702);
            this.Load += new System.EventHandler(this.GradeControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GradeDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuFlatButton Delete;
        private Bunifu.Framework.UI.BunifuFlatButton Update;
        private Bunifu.Framework.UI.BunifuFlatButton Add;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Year2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Year1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Year3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Year4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox StdName;
        private System.Windows.Forms.DataGridView GradeDataGridView;
    }
}
