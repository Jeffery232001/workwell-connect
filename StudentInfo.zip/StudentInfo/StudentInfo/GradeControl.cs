﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace StudentInfo
{
    public partial class GradeControl : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\hp pc\Documents\student.mdf"";Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            connect.Open();
            string Myquery = "select * from Grades";
            SqlDataAdapter dataAdapter = new SqlDataAdapter(Myquery, connect);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            GradeDataGridView.ReadOnly = true;
            GradeDataGridView.DataSource = ds.Tables[0];
            connect.Close();
        }
        public GradeControl()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GradeControl_Load(object sender, EventArgs e)
        {

        }

        private void GradeDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            StdName.Text = GradeDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            Year1.Text = GradeDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            Year2.Text = GradeDataGridView.SelectedRows[0].Cells[2].Value.ToString();
            Year3.Text = GradeDataGridView.SelectedRows[0].Cells[3].Value.ToString();
            Year4.Text = GradeDataGridView.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (StdName.Text == "" || Year1.Text == "" || Year2.Text == "" || Year3.Text == "" || Year4.Text == "")
            {
                MessageBox.Show("Missing Data.Fill All the Information");
            }
            else
            {

                connect.Open();
                SqlCommand cmd = new SqlCommand("insert into Grades values('" + StdName.Text + "','" + Year1.Text + "','" + Year2.Text + "','" + Year3.Text+ "','" + Year4.Text + "')", connect);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Grades Successfully Added");
                connect.Close();
                populate();
            }
        }

        private void Update_Click(object sender, EventArgs e)
        {

            connect.Open();
            String Myquery = "UPDATE Grades SET NAME = '" + StdName.Text + "', FYEAR = '" + Year1.Text + "',SYEAR ='" + Year2.Text + "', TYEAR = '" + Year3.Text + "', LYEAR = '" + Year4.Text + "'  WHERE NAME = '" + StdName.Text + "';";


            SqlCommand cmd = new SqlCommand(Myquery, connect);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Grades Updated Successfully");
            connect.Close();
            populate();
        }

        private void Delete_Click(object sender, EventArgs e)
        {

            if (StdName.Text == "")
            {
                MessageBox.Show("Wrong Operation.Click on the Grade to be Deleted");
            }
            else
            {
                if (DialogResult.Yes == MessageBox.Show("Are you sure to delete row?", "Comfirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {
                    connect.Open();
                    string query = "insert into Grades values('" + StdName.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, connect);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Grade Deleted Successfully");
                    connect.Close();
                    populate();

                }

            }
        }
    }
}
